See docs/index.html

pytest is needed to run tests in the 'tests' folder.